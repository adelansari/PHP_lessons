<?php
    // If the user is not logged in, redirect them back to login.php.

    // Check the POST parameter "bookid". If it's set, delete the corresponding book from the data file.
    // Hint: array_diff will not work here, since you'd need to create the whole book "object". Find the index and use array_splice instead.

    // Redirect back to admin.php.
